package com.test.spring_test.dto;

import jakarta.persistence.Column;
import lombok.Data;

@Data
public class CompantDto {

    private String companyName;
    @Column(name = "email")
    private String email;
    @Column(name = "strength")
    private Integer stregent;
    @Column(name = "webSiteURL")
    private String webSiteUrl;
    @Column(name = "company_code ")
    private String companyCode;

}






