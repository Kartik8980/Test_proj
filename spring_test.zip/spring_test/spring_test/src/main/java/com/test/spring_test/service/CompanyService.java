package com.test.spring_test.service;

import com.test.spring_test.dto.CompantDto;
import com.test.spring_test.entity.Company;
import com.test.spring_test.repo.CompanyRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CompanyService {

    @Autowired
    private CompanyRepo companyRepo;

    public Company saveCompany(CompantDto dto) {

        Company company=new Company();
        if(dto!=null) {
            company.setCompanyName(dto.getCompanyName());
            company.setEmail(dto.getEmail());
            company.setStregent(dto.getStregent());
            company.setWebSiteUrl(dto.getWebSiteUrl());
        }
        Company companyData = companyRepo.save(company);

        return companyData;
    }

    public Company getCompanyById(Long id)
    {
        Optional<Company> company = companyRepo.findById(id);

        if(company.isPresent())
        {
            return company.get();
        }
        else {
            throw new IllegalArgumentException("Data not found");
        }
    }

    public Optional<Company> getCompanyByCode(String code) {

        Optional<Company> companyByCode = companyRepo.getCompanyByCode(code);

        return companyByCode;
    }


    public Company updateCompany(Long id, Company company) {

        Optional<Company> byId = companyRepo.findById(id);

        if(byId.isPresent())
        {
            return byId.get();
        }
        else {
            throw new IllegalArgumentException("Data not found");
        }
    }



}
