package com.test.spring_test.controller;


import com.test.spring_test.dto.CompantDto;
import com.test.spring_test.entity.Company;
import com.test.spring_test.service.CompanyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/company")
public class CompanyController {

    @Autowired
    private CompanyService companyService;

    @PostMapping
    public ResponseEntity<Company> createCompany(@RequestBody CompantDto compantDto)
    {
        Company company = companyService.saveCompany(compantDto);
        return new ResponseEntity<>(company, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Company> getCompany(@PathVariable Long id)
    {
        Company companyById = companyService.getCompanyById(id);

        return new ResponseEntity<>(companyById, HttpStatus.OK);
    }

    @GetMapping("companyCode/{code}")
    public ResponseEntity<Company> getCompany(@PathVariable String code)
    {
        Optional<Company> companyByCode = companyService.getCompanyByCode(code);

        if(companyByCode.isPresent())
        {
            return new ResponseEntity<>(companyByCode.get(), HttpStatus.OK);
        }
        else {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @PatchMapping("/{id}")
    public ResponseEntity<Company> updateCompany(@PathVariable Long id, @RequestBody Company company)
    {
        Company company1 = companyService.updateCompany(id, company);
        return new ResponseEntity<>(company1, HttpStatus.OK);
    }


}
