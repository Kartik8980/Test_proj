package com.test.spring_test.repo;

import com.test.spring_test.entity.Company;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface CompanyRepo extends JpaRepository<Company,Long> {

    @Query("select * form Company where companyCode= : code")
    Optional<Company> getCompanyByCode(String code);

}
